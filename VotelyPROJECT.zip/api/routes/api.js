var express = require('express');
var router = express.Router();
var jwt = require('jsonwebtoken');
/* GET home page. */
router.get('/', function(req, res, next) {
 res.status(200).json({status:"OK", message:"Hello "+global.config.SERVER_NAME})
});

router.get("/getConfig", (req, res, next)=>{
    var token = req.headers['authorization'];
    jwt.verify(token, (err, decoded)=>{
        if(err) return res.send({error:{message:"Authorization key is malformed.", code:403}})
        if(decoded!==global.config.SECRET) return res.send({error:{message:"Authorization key invalid.", code:403}})
      next()
    })
}, (req, res)=>{
    res.statusCode(200).send(global.config)
})

module.exports = router;
