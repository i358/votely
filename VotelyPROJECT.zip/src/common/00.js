const config = {
  API_ENDPOINT: "http://localhost:3300",
  SITE_URI: "http://localhost",
  SERVER_ENDPOINT: "http://localhost:3000",
  SERVER_NAME: "Votely",
  DEFAULT_THEME: "dark",
  API_VERSION: "1",
  SECRET: "ccc359959s",
};

module.exports = config;
