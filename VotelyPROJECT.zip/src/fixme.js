var data = {
    "API_ENDPOINT":"http://localhost:3300",
}

module.exports = data;